<div class="php-run-once-actions">
    <button type="submit" class="button button-primary">Execute</button>
    <button type="button" class="button action" data-action="save">Save</button>

    <div data-action="load">
        <label for="load-script">Load saved script:</label>
        <select name="load-script" id="load-script">
            <option value="-1">-</option>
        </select>
        <button type="button" class="button action">Load</button>
    </div>
</div>